package com.example.storyapp.data.response

data class GeneralResponse(
    val error: Boolean,
    val message: String
)