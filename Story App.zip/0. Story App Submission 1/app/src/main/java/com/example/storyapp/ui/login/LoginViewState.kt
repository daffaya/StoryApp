package com.example.storyapp.ui.login

class LoginViewState {

}
